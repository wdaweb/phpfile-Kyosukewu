<!-- time -->
<?php
echo "現在時間:";
echo  $datetimenow;
?>