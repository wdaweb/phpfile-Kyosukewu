<!-- year,month -->
<?php
echo "西元-";
echo  $year;
echo "年-";
echo  $month;
echo "月";
?>